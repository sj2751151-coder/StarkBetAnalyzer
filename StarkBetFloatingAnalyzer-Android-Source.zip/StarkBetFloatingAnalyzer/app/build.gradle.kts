plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.manish.analyzer"
    compileSdk = 35
    defaultConfig { applicationId = "com.manish.analyzer"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "1.0" }
}
dependencies { implementation("com.google.mlkit:text-recognition:16.0.1") }
