package com.manish.analyzer
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
class MainActivity : Activity() {
 private val req=41
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val l=LinearLayout(this).apply { orientation=1; setPadding(24,40,24,24) }
  l.addView(TextView(this).apply { text="StarkBet Floating Analyzer\n\nस्क्रीन पर दिखने वाले टेक्स्ट को OCR से पढ़कर स्थानीय विश्लेषण करता है। अगले नंबर की गारंटी नहीं देता।"; textSize=18f })
  l.addView(Button(this).apply { text="1. Floating permission दें"; setOnClickListener { if(!Settings.canDrawOverlays(this@MainActivity)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) } })
  l.addView(Button(this).apply { text="2. Screen analysis शुरू करें"; setOnClickListener {
   if(!Settings.canDrawOverlays(this@MainActivity)){ Toast.makeText(this@MainActivity,"पहले Floating permission दें",Toast.LENGTH_LONG).show(); return@setOnClickListener }
   val m=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
   startActivityForResult(m.createScreenCaptureIntent(),req)
  }})
  l.addView(Button(this).apply { text="Analyzer बंद करें"; setOnClickListener { stopService(Intent(this@MainActivity,CaptureService::class.java)) } })
  setContentView(l)
 }
 @Deprecated("Deprecated")
 override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
  super.onActivityResult(requestCode,resultCode,data)
  if(requestCode==req && data!=null) {
   val i=Intent(this,CaptureService::class.java).putExtra("resultCode",resultCode).putExtra("data",data)
   if(android.os.Build.VERSION.SDK_INT>=26) startForegroundService(i) else startService(i)
  }
 }
}
