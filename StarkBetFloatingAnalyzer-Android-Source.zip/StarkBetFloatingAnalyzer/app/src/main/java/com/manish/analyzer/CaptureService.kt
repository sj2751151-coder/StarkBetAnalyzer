package com.manish.analyzer
import android.app.*
import android.content.Intent
import android.graphics.*
import android.hardware.display.*
import android.media.*
import android.media.projection.*
import android.os.*
import android.view.*
import android.widget.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class CaptureService: Service() {
 private var projection:MediaProjection?=null
 private var reader:ImageReader?=null
 private var display:VirtualDisplay?=null
 private var overlay:TextView?=null
 private var wm:WindowManager?=null
 private val handler=Handler(Looper.getMainLooper())
 private val recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
 private var previous=""
 override fun onBind(intent:Intent?)=null
 override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int {
  val ch="screen_analyzer"
  if(Build.VERSION.SDK_INT>=26) getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(ch,"Screen analyzer",NotificationManager.IMPORTANCE_LOW))
  val n=if(Build.VERSION.SDK_INT>=26) Notification.Builder(this,ch).setContentTitle("Floating Analyzer active").setContentText("Screen OCR running").setSmallIcon(android.R.drawable.ic_menu_search).build()
   else Notification.Builder(this).setContentTitle("Floating Analyzer active").setSmallIcon(android.R.drawable.ic_menu_search).build()
  startForeground(1,n)
  val code=intent?.getIntExtra("resultCode",0)?:0
  val data=if(Build.VERSION.SDK_INT>=33) intent?.getParcelableExtra("data",Intent::class.java) else @Suppress("DEPRECATION") intent?.getParcelableExtra("data") as? Intent
  if(data!=null) begin(code,data)
  return START_NOT_STICKY
 }
 private fun begin(code:Int,data:Intent) {
  val dm=resources.displayMetrics; val w=dm.widthPixels; val h=dm.heightPixels
  projection=(getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).getMediaProjection(code,data)
  reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2)
  display=projection?.createVirtualDisplay("Analyzer",w,h,dm.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader?.surface,null,handler)
  reader?.setOnImageAvailableListener({ r ->
   val image=r.acquireLatestImage()?:return@setOnImageAvailableListener
   val p=image.planes[0]; val bmp=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888)
   bmp.copyPixelsFromBuffer(p.buffer); image.close()
   val scaled=Bitmap.createScaledBitmap(bmp,w/2,h/2,true); bmp.recycle()
   recognizer.process(InputImage.fromBitmap(scaled,0)).addOnSuccessListener { result ->
    if(result.text!=previous) {
     previous=result.text
     val found=Regex("[0-9]").findAll(result.text).map{it.value}.toList().takeLast(12)
     show("Screen OCR active\nVisible digits: "+(found.joinToString(", ").ifEmpty{"none"})+"\n\nOCR may include timer, IDs or balance.")
    }
    scaled.recycle()
   }.addOnFailureListener { scaled.recycle() }
  },handler)
  show("Screen OCR active\nOpen the game screen.")
 }
 private fun show(s:String) { handler.post {
  if(overlay==null) {
   wm=getSystemService(WINDOW_SERVICE) as WindowManager
   overlay=TextView(this).apply { setTextColor(Color.WHITE); textSize=12f; setPadding(16,12,16,12); setBackgroundColor(0xEE10294D.toInt()) }
   val type=if(Build.VERSION.SDK_INT>=26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
   val lp=WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.END; y=120 }
   wm?.addView(overlay,lp)
  }
  overlay?.text=s
 }}
 override fun onDestroy() {
  display?.release(); reader?.close(); projection?.stop()
  overlay?.let { wm?.removeView(it) }; recognizer.close(); super.onDestroy()
 }
}
